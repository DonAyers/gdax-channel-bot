import React from "react";

class ThresholdInputs extends React.Component {
  //   constructor(props) {
  //     super(props);
  //   }

  render() {
    return (
      <div>
        <div className="ui labeled input">
          <div className="ui label">$</div>
          <input type="text" placeholder="Sell Threshold" />
        </div>
        <div className="ui labeled input">
          <div className="ui label">$</div>
          <input type="text" placeholder="Buy Threshold" />
        </div>
      </div>
    );
  }
}

export default ThresholdInputs;
