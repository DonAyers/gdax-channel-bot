import React from "react";
import Ticker from "./Ticker";
import ThresholdInputs from "./ThresholdInputs";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      coins: [
        { name: "BTC", price: null },
        { name: "ETH", price: null },
        { name: "LTC", price: null }
      ]
    };
  }

  componentDidMount() {
    const subscribe = {
      type: "subscribe",
      channels: [
        {
          name: "ticker",
          product_ids: ["BTC-USD", "ETH-USD", "LTC-USD"]
        }
      ]
    };

    this.ws = new WebSocket("wss://ws-feed.gdax.com");

    this.ws.onopen = () => {
      this.ws.send(JSON.stringify(subscribe));
    };

    this.ws.onmessage = e => {
      const value = JSON.parse(e.data);
      if (value.type !== "ticker") return;
      var i = 0;
      // 1. Make a shallow copy of the items
      let coins = [...this.state.coins];
      // 2. Make a shallow copy of the item you want to mutate

      switch (value.product_id) {
        case "BTC-USD":
          i = 0;
          //
          break;

        case "ETH-USD":
          i = 1;
          //
          break;

        case "LTC-USD":
          i = 2;
          //
          break;
        default:
          break;
      }

      let coin = { ...coins[i] };
      // 3. Replace the property you're intested in
      coin.price = value.price;
      // 4. Put it back into our array. N.B. we *are* mutating the array here, but that's why we made a copy first
      coins[i] = coin;
      // 5. Set the state to our new copy
      this.setState({ coins });
      //
    };

    // --------------public client test ------------------------
    const Gdax = require("gdax");
    //const publicClient = new Gdax.PublicClient();
    //All methods, unless otherwise specified, can be used with either a promise or callback API.

    //Using Promises
    // publicClient
    //   .getProducts()
    //   .then(data => {
    //
    //   })
    //   .catch(error => {
    //
    //   });

    // ---------------auth client test------------------------
    const key = "3aeafcb707316aa987c064455388805e";
    const secret =
      "MuBHz6M+9z6OItfzDABtvghgJGvk8X0SIvfm+NNo/Fz/yxl3TJo13Ol6vv+1A6k2HfrONRHs2VnlqKoAf5BVag==";
    const passphrase = "5ixu6tbqpym";
    const proxyURI = "http://localhost:8080/";

    //const apiURI = "https://api.pro.coinbase.com";
    const sandboxURI = "https://api-public.sandbox.pro.coinbase.com";
    const combinedURI = proxyURI + sandboxURI;

    const authedClient = new Gdax.AuthenticatedClient(
      key,
      secret,
      passphrase,
      combinedURI
    );

    authedClient
      .getProducts()
      .then(data => {
        console.log(data);
      })
      .catch(error => {
        console.log(error);
      });

    var callback = function(error, response, data) {
      if (error) {
        console.log(error);
      } else {
        if (response) console.log(response);
        if (data) console.log(data);
      }
    };
    // Buy 1 BTC @ 100 USD
    const buyParams = {
      price: "45.00", // USD
      size: "1", // BTC
      product_id: "BTC-USD"
    };
    authedClient.buy(buyParams, callback);

    // Sell 1 BTC @ 110 USD
    const sellParams = {
      price: "110.00", // USD
      size: "1", // BTC
      product_id: "BTC-USD"
    };
    authedClient.sell(sellParams, callback);

    authedClient.getOrders(callback);
  }

  componentWillUnmount() {
    this.ws.close();
  }

  render() {
    return (
      <div className="ui segment container">
        <h1 className="ui center aligned header">coin-bot v1</h1>
        <Ticker coins={this.state.coins} />
        <ThresholdInputs />
      </div>
    );
  }
}

export default App;
